package com.edu;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENTS")
public class Student {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Student_Id")
	private int Sid;
	@Column(name="Name",length=40,nullable = false)
	private String Sname;
	@Column(nullable = false)
	private int age;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Cid")
	private Course cousre;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Student(String sname, int age) {
		super();
		Sname = sname;
		this.age = age;
	}
	
	public int getSid() {
		return Sid;
	}
	public void setSid(int sid) {
		Sid = sid;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Course getCousre() {
		return cousre;
	}

	public void setCousre(Course cousre) {
		this.cousre = cousre;
	}
	@Override
	public String toString() {
		return "Student [Sid=" + Sid + ", Sname=" + Sname + ", age=" + age + "]";
	}
}

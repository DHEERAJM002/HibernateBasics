package com.edu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {
	public static void main(String[] args) {
		Configuration configObj=new Configuration()
				.configure()
				.addAnnotatedClass(Student.class)
				.addAnnotatedClass(Course.class);
		
		SessionFactory sessionFactObj=configObj.buildSessionFactory();
		Session sessionObj=sessionFactObj.openSession();
		Transaction transactionObj=sessionObj.beginTransaction();
		
		Course courseObj=new Course("AWS",45000);
		
		Student stObj1=new Student("Aman",22);
		Student stObj2=new Student("Bhuvan",23);
		Student stObj3=new Student("Charith",21);
		Student stObj4=new Student("Dev",23);
		Student stObj5=new Student("Eshaan",24);
		
		List<Student> slist=new ArrayList<Student>();
		
		slist.add(stObj1);
		slist.add(stObj2);
		slist.add(stObj3);
		slist.add(stObj4);
		slist.add(stObj5);
		courseObj.setsList(slist);
		
		sessionObj.save(courseObj);
		transactionObj.commit();
		sessionObj.close();
	}
	
	
}

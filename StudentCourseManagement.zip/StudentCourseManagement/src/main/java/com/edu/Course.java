package com.edu;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "COURSES")
public class Course {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Course_ID")
	private int Cid;
	@Column(name="Name",length = 30,nullable = false)
	private String CName;
	@Column(name="Fees",nullable = false)
	private float fCees;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Cid")
	List<Student> sList=new ArrayList<Student>();
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Course(String cName, float fCees) {
		super();
		CName = cName;
		this.fCees = fCees;
	}
	
	public int getCid() {
		return Cid;
	}

	public void setCid(int cid) {
		Cid = cid;
	}

	public String getCName() {
		return CName;
	}

	public void setCName(String cName) {
		CName = cName;
	}

	public float getfCees() {
		return fCees;
	}

	public void setfCees(float fCees) {
		this.fCees = fCees;
	}
	
	public List<Student> getsList() {
		return sList;
	}

	public void setsList(List<Student> sList) {
		this.sList = sList;
	}

	@Override
	public String toString() {
		return "Course [Cid=" + Cid + ", CName=" + CName + ", fCees=" + fCees + "]";
	}

}
